﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Delivery.Pages.ContentPages;
using Delivery.Pages.ContentPages.AdminPanel;
using Gym.Database;
using Gym.Pages.ContentPages;
//using Gym.Pages.ContentPages.Clients;
using Gym.Pages.ContentPages.Hall;
//using Gym.Pages.ContentPages.SportTable;
//using Gym.Pages.ContentPages.Subscriptions;
//using Gym.Pages.ContentPages.Trainers;
//using Gym.Pages.Profile;
using Frame = ModernWpf.Controls.Frame;
//using TrainersPage = Gym.Pages.ContentPages.Trainers.TrainersPage;

namespace Gym.Pages;

public partial class MainPage : Page
{
    private readonly User _user;
    private readonly Frame _frame;
    
    public MainPage(User user, ModernWpf.Controls.Frame frame)
    {
        _frame = frame;
        _user = user;
        InitializeComponent();
        
        NameTextBlock.Text = _user.Role.Name;
        if (_user.Role.Name == "Пользователь" || _user.Role.Name == "Доставщик")
        {
            AdminPanelButtonE.IsEnabled = false;
            AdminPanelButtonE.Visibility = Visibility.Hidden;
        }
        
        //ContentFrame.Navigate(new SportTablePage());
    }

    private void TableButton_OnClick(object sender, RoutedEventArgs e)
    {
        //ContentFrame.Navigate(new SportTablePage());
        ContentFrame.Navigate(new HallsPage());
    }

    private void HallsButton_OnClick(object sender, RoutedEventArgs e)
    {
        ContentFrame.Navigate(new CartPage());
    }

    private void TrainersButton_OnClick(object sender, RoutedEventArgs e)
    {
        //ContentFrame.Navigate(new TrainersPage());
    }

    private void SubscriptionsButton_OnClick(object sender, RoutedEventArgs e)
    {
        //ContentFrame.Navigate(new SubscriptionPage());
    }

    private void ClientsButton_OnClick(object sender, RoutedEventArgs e)
    {
        //ContentFrame.Navigate(new ClientsPage());
    }

    private void UIElement_OnMouseDown(object sender, MouseButtonEventArgs e)
    {
        //ContentFrame.Navigate(new ProfilePage(_user, _frame));
    }

    private void AdminPanelButtonE_Click(object sender, RoutedEventArgs e)
    {
        ContentFrame.Navigate(new AdminPanel());
    }

    private void OrdersButton_Click(object sender, RoutedEventArgs e)
    {
        ContentFrame.Navigate(new DeliverOrderPage());
    }
}