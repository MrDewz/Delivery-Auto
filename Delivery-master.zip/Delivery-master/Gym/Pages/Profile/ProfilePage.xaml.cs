﻿//using System.Windows;
//using System.Windows.Controls;
//using Gym.Database;
//using Frame = ModernWpf.Controls.Frame;

//namespace Gym.Pages.Profile;

//public partial class ProfilePage : Page
//{
//    private readonly Frame _frame;
    
//    public ProfilePage(Worker worker, Frame frame)
//    {
//        _frame = frame;
        
//        InitializeComponent();
        
//        if (worker.PersonalInfo != null)
//            NameTextBlock.Text =
//                worker.PersonalInfo.Passport?.LastName +
//                " " +
//                worker.PersonalInfo.Passport?.FirstName +
//                " " +
//                worker.PersonalInfo.Passport?.MiddleName;
        
        
//    }

//    private void ButtonBase_OnClick(object sender, RoutedEventArgs e)
//    {
//        _frame.Navigate(new LoginPage(_frame));
//    }
//}