﻿using Gym.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Delivery.Database;
using Gym.Database;
using Microsoft.EntityFrameworkCore;
using System.Windows.Controls.Primitives;
using Gym.Pages.ContentPages.Hall;

namespace Delivery.Pages.ContentPages
{
    /// <summary>
    /// Логика взаимодействия для CartPage.xaml
    /// </summary>
    public partial class CartPage : Page
    {
        private DeliveryContext _context;
        List<Product> product = new List<Product>();
       

        public CartPage()
        {
            _context = new DeliveryContext();
            InitializeComponent();
            ShowTable("");
        }

        private void ShowTable(string search)
        {

            if (string.IsNullOrWhiteSpace(search))
            {
                product = CartList.products;
            }
            else
            {
                product = CartList.products.Where(c => c.Name.Contains(search) || c.Description.Contains(search)).ToList();
            }

            if (product.Count == 0)
                NothingVisibleTextBlock.Visibility = Visibility.Visible;
            else
                NothingVisibleTextBlock.Visibility = Visibility.Collapsed;

            TableListView.ItemsSource = null;
            TableListView.ItemsSource = product;
        }

        private void SearchTextBox_OnTextChanged(object sender, TextChangedEventArgs e)
        {
            ShowTable(SearchTextBox.Text);
        }


        private void PayButton_Click(object sender, RoutedEventArgs e)
        {
            double Sum = PriceSum();
            NavigationService.Navigate(new Payment(Sum));
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            TableListView.ItemsSource = null;
            CartList.products.Clear();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            ShowTable(SearchTextBox.Text);
        }

        private double PriceSum()
        {
            double Sum = 0;
            for (int i = 0; i < TableListView.Items.Count; i++)
            {
                var pr = TableListView.Items[i] as Product;
                if (pr != null)
                {
                    Sum += Convert.ToDouble(pr.Price.Value);
                }
                
            }
            return Sum;
            //_context.Products[];
        }
    }
}
