﻿using System;
using System.Windows;
using System.Windows.Controls;
using Gym.Database;

namespace Gym.Pages.ContentPages.SportGroup;

public partial class AddSportGroupPage : Page
{
    public Database.SportGroup SportGroup { get; set; } = new Database.SportGroup();

    private readonly DeliveryContext _context;
    
    public AddSportGroupPage()
    {
        _context = new DeliveryContext();
        InitializeComponent();
        DataContext = SportGroup;
    }

    private void SaveButton_OnClick(object sender, RoutedEventArgs e)
    {
        try
        {
            _context.SportGroups.Add(SportGroup);
            _context.SaveChanges();
            
            MessageBox.Show("Успешно сохранено!");
                
            if (NavigationService != null)
                NavigationService.GoBack();
        }
        catch (Exception exception)
        {
            MessageBox.Show("Неверные данные");
        }
    }

    private void CancelButton_OnClick(object sender, RoutedEventArgs e)
    {
        var result = MessageBox.Show("Отменить?", "", MessageBoxButton.YesNo);
        
        if (result == MessageBoxResult.Yes)
        {
            if (NavigationService != null) 
                NavigationService.GoBack();
        }
    }
}