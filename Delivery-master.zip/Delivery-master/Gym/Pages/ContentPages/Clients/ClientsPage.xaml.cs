﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Gym.Database;
using Microsoft.EntityFrameworkCore;

namespace Gym.Pages.ContentPages.Clients;

public partial class ClientsPage : Page
{
    private DeliveryContext _context;

    public ClientsPage()
    {
        _context = new DeliveryContext();
        InitializeComponent();

        ShowTable("");
    }

    private void ShowTable(string search)
    {
        List<Client> сlients;

        if (string.IsNullOrWhiteSpace(search))
        {
            сlients = _context.Clients
                .Include(c => c.PersonalInfo)
                .ThenInclude(c => c!.Passport)
                .ToList();
        }
        else
        {
            сlients = _context.Clients
                .Include(c => c.PersonalInfo)
                .ThenInclude(c => c!.Passport)
                
                .Where(c => c.PersonalInfo.Passport.LastName.Contains(search) ||
                            c.PersonalInfo.Passport.FirstName.Contains(search))
                .ToList();
        }

        if (сlients.Count == 0)
            NothingVisibleTextBlock.Visibility = Visibility.Visible;
        else
            NothingVisibleTextBlock.Visibility = Visibility.Collapsed;

        TrainersListView.ItemsSource = null;
        TrainersListView.ItemsSource = сlients;
    }

    private void SearchTextBox_OnTextChanged(object sender, TextChangedEventArgs e)
    {
        ShowTable(SearchTextBox.Text);
    }

    private void AddButton_OnClick(object sender, RoutedEventArgs e)
    {
        if (NavigationService != null)
            NavigationService.Navigate(new AddEditClientsPage());
    }

    private void EditButton_OnClick(object sender, RoutedEventArgs e)
    {
        var selected = TrainersListView.SelectedItem as Client;

        if (selected != null)
        {
            if (NavigationService != null)
                NavigationService.Navigate(new AddEditClientsPage(selected));
        }
        else
        {
            MessageBox.Show("Необходимо выбрать клиента");
        }
    }

    private void DeleteButton_OnClick(object sender, RoutedEventArgs e)
    {
        var selected = TrainersListView.SelectedItem as Database.Client;

        if (selected != null)
        {
            var result = MessageBox.Show("Удалить?", "", MessageBoxButton.YesNo);
            try
            {
                if (result == MessageBoxResult.Yes)
                {
                    _context.Clients.Remove(selected);
                    _context.SaveChanges();

                    ShowTable(SearchTextBox.Text);
                }

                else
                {
                    MessageBox.Show("Необходимо выбрать клиента");
                }
            }
            catch
            {
                MessageBox.Show("Не удалось удалить клиента.");
            }

        }

    }
    private void ClientsPage_OnLoaded(object sender, RoutedEventArgs e)
    {
        ShowTable(SearchTextBox.Text);
    }
}