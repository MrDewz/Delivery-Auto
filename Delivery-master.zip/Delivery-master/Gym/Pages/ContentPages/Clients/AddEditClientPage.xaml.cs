﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using Gym.Database;
using Gym.Pages.ContentPages.SportGroup;
using Microsoft.Win32;

namespace Gym.Pages.ContentPages.Clients;

public partial class AddEditClientsPage : Page, INotifyPropertyChanged
{
    private readonly DeliveryContext _context;
    private string? _imagePath;

    public string? ImagePath
    {
        get => _imagePath;
        set
        {
            if (value == _imagePath) return;
            _imagePath = value;
            OnPropertyChanged();
        }
    }

    public Client Client { get; set; }
    public PersonalInfo PersonalInfo { get; set; }
    public Passport Passport { get; set; }
    
    public List<Database.SportGroup> SportGroups { get; set; }

    public AddEditClientsPage()
    {
        _context = new DeliveryContext();
        Client = new Client();
        PersonalInfo = new PersonalInfo();
        Passport = new Passport();
        
        InitializeComponent();
        
        DataContext = this;

        SportGroups = new List<Database.SportGroup>() { new Database.SportGroup() { Id = -1, Name = "Не выбрано" } };
        
        SportGroups.AddRange(_context.SportGroups.ToList());

        GroupComboBox.ItemsSource = SportGroups;
        
        GroupComboBox.SelectedItem = SportGroups.ElementAt(0);
    }
    
    public AddEditClientsPage(Client client)
    {
        _context = new DeliveryContext();
        
        Client = client;
        
        if (client.PersonalInfo != null)
        {
            PersonalInfo = client.PersonalInfo;
            
            if (client.PersonalInfo.Passport != null)
                Passport = client.PersonalInfo.Passport;
            else
                Passport = new Passport();
        }
        else
        {
            PersonalInfo = new PersonalInfo();
            Passport = new Passport();
        }

        InitializeComponent();
        
        DataContext = this;
        
        SetImage(PersonalInfo.ImagePath);
        
        SportGroups = new List<Database.SportGroup>() { new Database.SportGroup() { Id = -1, Name = "Не выбрано" } };

        GroupComboBox.ItemsSource = SportGroups;
        
        GroupComboBox.SelectedItem = SportGroups.FirstOrDefault(c => client.SportGroup != null &&
                                                                     c.Id == client.SportGroup.Id) ??
                                     SportGroups.ElementAt(0);
    }
    
    private void DeleteImageButton_OnClick(object sender, RoutedEventArgs e)
    {
        SetImage(null);
    }
    
    private string? CopyImageToDocs(string? filePath)
    {
        if (filePath == null)
            return null;
        
        var path = $"C:\\Users\\{Environment.UserName}\\Documents\\Images\\";
        
        string fileName = "Image_" + App.GetTimeStamp() + ".png";
        File.Copy(filePath, path + fileName);
        return fileName;
    }
    
    private void ChooseImageButton_OnClick(object sender, RoutedEventArgs e)
    {
        var dir = "C:\\";
        var filter = "Image files (*.png)|*.png|All files (*.*)|*.*";

        // открываем диалог выбора файла
        var openFileDialog = new OpenFileDialog();

        openFileDialog.InitialDirectory = dir;
        openFileDialog.Filter = filter;

        // если показан
        if (openFileDialog.ShowDialog() == true)
            // если есть выбранный файл
            if (openFileDialog.FileName != string.Empty)
                SetImage(openFileDialog.FileName);
    }

    private void SetImage(string? path)
    {
        ImagePath = path;
    }

    private void Image_OnDrop(object sender, DragEventArgs e)
    {
        if (e.Data.GetDataPresent(DataFormats.FileDrop))
        {
            var data = e.Data.GetData(DataFormats.FileDrop);

            if (data != null)
            {
                var files = (string[]) data;

                if (files.Length > 0)
                {
                    var file = files[0];

                    if (file.EndsWith(".png") || file.EndsWith(".jpg"))
                        SetImage(file);
                }
            }
        }
    }

    private void SaveButton_OnClick(object sender, RoutedEventArgs e)
    {
        if (!ValidatePassport())
        {
            MessageBox.Show("Не все паспортные данные верны");
            return;
        }

        if (PersonalInfo.Email != String.Empty)
        {
            if (!ValidatePersonalInfo())
            {
                MessageBox.Show("Почта неверного формата");
                return;
            }
        }
        else
        {
            PersonalInfo.Email = null;
        }

        if (Passport.Id == 0)
        {
            try
            {
                _context.Passports.Add(Passport);
                _context.SaveChanges();

                PersonalInfo.PassportId = Passport.Id;
                PersonalInfo.PhotoPath = CopyImageToDocs(ImagePath);
                
                _context.PersonalInfos.Add(PersonalInfo);
                _context.SaveChanges();

                Client.PersonalInfoId = PersonalInfo.Id;

                _context.Clients.Add(Client);
                _context.SaveChanges();

                var sportGroup = GroupComboBox.SelectedItem as Database.SportGroup;

                if (sportGroup.Id != -1)
                {
                    ClientSportGroup clientSportGroup = new ClientSportGroup();
                    clientSportGroup.ClientId = Client.Id;
                    clientSportGroup.SportGroupId = sportGroup.Id;
                    _context.ClientSportGroups.Add(clientSportGroup);
                    _context.SaveChanges();
                }

                MessageBox.Show("Сохранено!");
                
                if (NavigationService != null)
                    NavigationService.GoBack();
            }
            catch (Exception exception)
            {
                MessageBox.Show("Неверные данные");
            }
            
        }
        else
        {
            try
            {
                _context.Passports.Update(Passport);
                _context.SaveChanges();

                PersonalInfo.PassportId = Passport.Id;
                PersonalInfo.PhotoPath = CopyImageToDocs(ImagePath);
                
                _context.PersonalInfos.Update(PersonalInfo);
                _context.SaveChanges();

                Client.PersonalInfoId = PersonalInfo.Id;

                _context.Clients.Update(Client);
                _context.SaveChanges();
 
                var sportGroup = GroupComboBox.SelectedItem as Database.SportGroup;

                if (sportGroup.Id != -1)
                {
                    ClientSportGroup clientSportGroup = new ClientSportGroup();
                    clientSportGroup.ClientId = Client.Id;
                    clientSportGroup.SportGroupId = sportGroup.Id;
                    _context.ClientSportGroups.Add(clientSportGroup);
                    _context.SaveChanges();
                }
                
                MessageBox.Show("Сохранено!");
                
                if (NavigationService != null)
                    NavigationService.GoBack();
            }
            catch (Exception exception)
            {
                MessageBox.Show("Неверные данные");
            }
        }
        
        
    }

    private void CancelButton_OnClick(object sender, RoutedEventArgs e)
    {
        var result = MessageBox.Show("Отменить?", "", MessageBoxButton.YesNo);
        
        if (result == MessageBoxResult.Yes)
        {
            if (NavigationService != null) 
                NavigationService.GoBack();
        }
    }

    private bool ValidatePassport()
    {
        if (Passport.Number.ToString().Length != 6)
            return false;

        if (Passport.Serial.ToString().Length != 4)
            return false;

        if (string.IsNullOrWhiteSpace(Passport.LastName) ||
            string.IsNullOrWhiteSpace(Passport.FirstName))
            return false;

        if (Passport.BirthDate.Year < new DateTime(2000, 1, 1).Year)
            return false;
        if (Passport.BirthDate.Year > new DateTime(2017, 1, 1).Year)
            return false;

            return true;
    }

    private bool ValidatePersonalInfo()
    {
        if (PersonalInfo.Email != null &&
            !ValidateEmail(PersonalInfo.Email))
            return false;

        return true;
    }
    
    private bool ValidateEmail(string email)
    {
        return new EmailAddressAttribute().IsValid(email);
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    protected bool SetField<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value)) return false;
        field = value;
        OnPropertyChanged(propertyName);
        return true;
    }

    private void CreateSportGroup_OnClick(object sender, RoutedEventArgs e)
    {
        if (NavigationService != null) 
            NavigationService.Navigate(new AddSportGroupPage());
    }

    private void AddEditClientsPage_OnLoaded(object sender, RoutedEventArgs e)
    {
        SportGroups = new List<Database.SportGroup>() { new Database.SportGroup() { Id = -1, Name = "Не выбрано" } };
        
        SportGroups.AddRange(_context.SportGroups.ToList());
        
        GroupComboBox.ItemsSource = SportGroups;
        
        GroupComboBox.SelectedItem = SportGroups.FirstOrDefault(c => Client.SportGroup != null && c.Id == Client.SportGroup.Id) ?? SportGroups.ElementAt(0);
    }
}