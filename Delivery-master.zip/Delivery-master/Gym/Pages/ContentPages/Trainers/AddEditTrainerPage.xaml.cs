﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using Gym.Database;
using Microsoft.Win32;

namespace Gym.Pages.ContentPages.Trainers;

public partial class AddEditTrainerPage : Page, INotifyPropertyChanged
{
    private readonly DeliveryContext _context;
    private string? _imagePath;

    public string? ImagePath
    {
        get => _imagePath;
        set
        {
            if (value == _imagePath) return;
            _imagePath = value;
            OnPropertyChanged();
        }
    }

    public Trainer Trainer { get; set; }
    public PersonalInfo PersonalInfo { get; set; }
    public Passport Passport { get; set; }
    
    public AddEditTrainerPage()
    {
        _context = new DeliveryContext();
        Trainer = new Trainer();
        PersonalInfo = new PersonalInfo();
        Passport = new Passport();
        
        InitializeComponent();
        
        DataContext = this;
    }
    
    public AddEditTrainerPage(Trainer trainer)
    {
        _context = new DeliveryContext();
        
        Trainer = trainer;
        
        if (trainer.PersonalInfo != null)
        {
            PersonalInfo = trainer.PersonalInfo;
            
            if (trainer.PersonalInfo.Passport != null)
                Passport = trainer.PersonalInfo.Passport;
            else
                Passport = new Passport();
        }
        else
        {
            PersonalInfo = new PersonalInfo();
            Passport = new Passport();
        }

        InitializeComponent();
        
        DataContext = this;
        
        SetImage(PersonalInfo.ImagePath);
    }
    
    private void DeleteImageButton_OnClick(object sender, RoutedEventArgs e)
    {
        SetImage(null);
    }
    
    private string? CopyImageToDocs(string? filePath)
    {
        if (filePath == null)
            return null;
        
        var path = $"C:\\Users\\{Environment.UserName}\\Documents\\Images\\";
        
        string fileName = "Image_" + App.GetTimeStamp() + ".png";
        File.Copy(filePath, path + fileName);
        return fileName;
    }
    
    private void ChooseImageButton_OnClick(object sender, RoutedEventArgs e)
    {
        var dir = "C:\\";
        var filter = "Image files (*.png)|*.png|All files (*.*)|*.*";

        // открываем диалог выбора файла
        var openFileDialog = new OpenFileDialog();

        openFileDialog.InitialDirectory = dir;
        openFileDialog.Filter = filter;

        // если показан
        if (openFileDialog.ShowDialog() == true)
            // если есть выбранный файл
            if (openFileDialog.FileName != string.Empty)
                SetImage(openFileDialog.FileName);
    }

    private void SetImage(string? path)
    {
        ImagePath = path;
    }

    private void Image_OnDrop(object sender, DragEventArgs e)
    {
        if (e.Data.GetDataPresent(DataFormats.FileDrop))
        {
            var data = e.Data.GetData(DataFormats.FileDrop);

            if (data != null)
            {
                var files = (string[]) data;

                if (files.Length > 0)
                {
                    var file = files[0];

                    if (file.EndsWith(".png") || file.EndsWith(".jpg"))
                        SetImage(file);
                }
            }
        }
    }

    private void SaveButton_OnClick(object sender, RoutedEventArgs e)
    {
        if (!ValidatePassport())
        {
            MessageBox.Show("Не все паспортные данные верны");
            return;
        }

        if (PersonalInfo.Email != String.Empty)
        {
            if (!ValidatePersonalInfo())
            {
                MessageBox.Show("Почта неверного формата");
                return;
            }
        }
        else
        {
            PersonalInfo.Email = null;
        }

        if (Passport.Id == 0)
        {
            try
            {
                _context.Passports.Add(Passport);
                _context.SaveChanges();

                PersonalInfo.PassportId = Passport.Id;
                PersonalInfo.PhotoPath = CopyImageToDocs(ImagePath);
                
                _context.PersonalInfos.Add(PersonalInfo);
                _context.SaveChanges();

                Trainer.PersonalInfoId = PersonalInfo.Id;

                _context.Trainers.Add(Trainer);
                _context.SaveChanges();

                MessageBox.Show("Сохранено!");
                
                if (NavigationService != null)
                    NavigationService.GoBack();
            }
            catch (Exception exception)
            {
                MessageBox.Show("Неверные данные");
            }
            
        }
        else
        {
            try
            {
                var age = Trainer.DateOfStartWork.Year - Passport.BirthDate.Year;
                _context.Passports.Update(Passport);
                _context.SaveChanges();

                PersonalInfo.PassportId = Passport.Id;
                PersonalInfo.PhotoPath = CopyImageToDocs(ImagePath);
                
                _context.PersonalInfos.Update(PersonalInfo);
                _context.SaveChanges();

                Trainer.PersonalInfoId = PersonalInfo.Id;

                _context.Trainers.Update(Trainer);
                _context.SaveChanges();
 
                MessageBox.Show("Сохранено!");
                
                if (NavigationService != null)
                    NavigationService.GoBack();
            }
            catch (Exception exception)
            {
                MessageBox.Show("Неверные данные");
            }
        }
        
        
    }

    private void CancelButton_OnClick(object sender, RoutedEventArgs e)
    {
        var result = MessageBox.Show("Отменить?", "", MessageBoxButton.YesNo);
        
        if (result == MessageBoxResult.Yes)
        {
            if (NavigationService != null) 
                NavigationService.GoBack();
        }
    }

    private bool ValidatePassport()
    {
        if (Passport.Number.ToString().Length != 6)
            return false;

        if (Passport.Serial.ToString().Length != 4)
            return false;

        if (string.IsNullOrWhiteSpace(Passport.LastName) ||
            string.IsNullOrWhiteSpace(Passport.FirstName))
            return false;


            if (Passport.BirthDate.Year < new DateTime(1970, 1, 1).Year)
                return false;
            if (Trainer.DateOfStartWork.Year < new DateTime(2011,1, 1).Year)
            return false;
        return true;
    }

    private bool ValidatePersonalInfo()
    {
        if (PersonalInfo.Email != null &&
            !ValidateEmail(PersonalInfo.Email))
            return false;

        return true;
    }
    
    private bool ValidateEmail(string email)
    {
        return new EmailAddressAttribute().IsValid(email);
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    protected bool SetField<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value)) return false;
        field = value;
        OnPropertyChanged(propertyName);
        return true;
    }
}