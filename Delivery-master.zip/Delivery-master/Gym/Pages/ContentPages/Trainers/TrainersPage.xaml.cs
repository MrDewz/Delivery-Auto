﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using Gym.Database;
using Gym.Pages.ContentPages.Hall;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualBasic.CompilerServices;

namespace Gym.Pages.ContentPages.Trainers;

public partial class TrainersPage : Page
{
 private DeliveryContext _context;

 public TrainersPage()
    {
        _context = new DeliveryContext();
        InitializeComponent();

        SortComboBox.SelectedIndex = 0;
        
        ShowTable("", SortComboBox.SelectedIndex);
    }
    
    private void ShowTable(string search, int sort)
    {
        List<Trainer> trainers;

        if (string.IsNullOrWhiteSpace(search))
        {
            trainers = _context.Trainers
                .Include(c => c.PersonalInfo)
                .ThenInclude(c => c!.Passport)
                .ToList();
        }
        else
        {
            trainers = _context.Trainers
                .Include(c => c.PersonalInfo)
                .ThenInclude(c => c!.Passport)
                .Where(c => c.PersonalInfo.Passport.LastName.Contains(search) ||
                            c.PersonalInfo.Passport.FirstName.Contains(search))
                .ToList();
        }

        if (sort == 0)
        {
            trainers = trainers.OrderBy(c => c.Id).ToList();
        }

        if (sort == 1)
        {
            trainers = trainers.OrderBy(c => c.DateOfStartWork).ToList();
        }
        
        if (trainers.Count == 0)
            NothingVisibleTextBlock.Visibility = Visibility.Visible;
        else
            NothingVisibleTextBlock.Visibility = Visibility.Collapsed;
        
        TrainersListView.ItemsSource = null;
        TrainersListView.ItemsSource = trainers;
    }
    
    private void SearchTextBox_OnTextChanged(object sender, TextChangedEventArgs e)
    {
        ShowTable(SearchTextBox.Text, SortComboBox.SelectedIndex);
    }

    private void AddButton_OnClick(object sender, RoutedEventArgs e)
    {
        if (NavigationService != null) 
            NavigationService.Navigate(new AddEditTrainerPage());
    }

    private void EditButton_OnClick(object sender, RoutedEventArgs e)
    {
        var selected = TrainersListView.SelectedItem as Trainer;
        
        if (selected != null)
        {
            if (NavigationService != null) 
                NavigationService.Navigate(new AddEditTrainerPage(selected));
        }
        else
        {
            MessageBox.Show("Необходимо выбрать тренера");
        }
    }

    private void DeleteButton_OnClick(object sender, RoutedEventArgs e)
    {
        var selected = TrainersListView.SelectedItem as Database.Trainer;
        
        if (selected != null)
        {
            var result = MessageBox.Show("Удалить?", "", MessageBoxButton.YesNo);
            
            if (result == MessageBoxResult.Yes)
            {
                _context.Trainers.Remove(selected);
                _context.SaveChanges();

                ShowTable(SearchTextBox.Text, SortComboBox.SelectedIndex);
            }
        }
        else
        {
            MessageBox.Show("Необходимо выбрать тренера");
        }
    }

    private void SortComboBox_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        ShowTable(SearchTextBox.Text, SortComboBox.SelectedIndex);
    }

    private void TrainersPage_OnLoaded(object sender, RoutedEventArgs e)
    {
        ShowTable(SearchTextBox.Text, SortComboBox.SelectedIndex);
    }
}