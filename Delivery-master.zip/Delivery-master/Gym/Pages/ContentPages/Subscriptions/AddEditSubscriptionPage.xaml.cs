﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using Gym.Database;
using Microsoft.Win32;

namespace Gym.Pages.ContentPages.Subscriptions;

public partial class AddEditSubscriptionPage : Page, INotifyPropertyChanged
{
    private readonly DeliveryContext _context;
    private string? _imagePath;

    public string? ImagePath
    {
        get => _imagePath;
        set
        {
            if (value == _imagePath) return;
            _imagePath = value;
            OnPropertyChanged();
        }
    }
    public Subscription Subscription { get; set; }

    public AddEditSubscriptionPage()
    {
        _context = new DeliveryContext();
        Subscription = new Subscription();

        InitializeComponent();
        
        DataContext = this;
    }
    
    public AddEditSubscriptionPage(Subscription subscription)
    {
        _context = new DeliveryContext();
        
        Subscription = subscription;
        
        InitializeComponent();
        
        DataContext = this;
        
        SetImage(subscription.ImagePath);
    }
    
    private void DeleteImageButton_OnClick(object sender, RoutedEventArgs e)
    {
        SetImage(null);
    }
    
    private string? CopyImageToDocs(string? filePath)
    {
        if (filePath == null)
            return null;
        
        var path = $"C:\\Users\\{Environment.UserName}\\Documents\\Images\\";
        
        string fileName = "Image_" + App.GetTimeStamp() + ".png";
        File.Copy(filePath, path + fileName);
        return fileName;
    }
    
    private void ChooseImageButton_OnClick(object sender, RoutedEventArgs e)
    {
        var dir = "C:\\";
        var filter = "Image files (*.png)|*.png|All files (*.*)|*.*";

        // открываем диалог выбора файла
        var openFileDialog = new OpenFileDialog();

        openFileDialog.InitialDirectory = dir;
        openFileDialog.Filter = filter;

        // если показан
        if (openFileDialog.ShowDialog() == true)
            // если есть выбранный файл
            if (openFileDialog.FileName != string.Empty)
                SetImage(openFileDialog.FileName);
    }

    private void SetImage(string? path)
    {
        ImagePath = path;
    }

    private void Image_OnDrop(object sender, DragEventArgs e)
    {
        if (e.Data.GetDataPresent(DataFormats.FileDrop))
        {
            var data = e.Data.GetData(DataFormats.FileDrop);

            if (data != null)
            {
                var files = (string[]) data;

                if (files.Length > 0)
                {
                    var file = files[0];

                    if (file.EndsWith(".png") || file.EndsWith(".jpg"))
                        SetImage(file);
                }
            }
        }
    }

    private void SaveButton_OnClick(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(NameTextBox.Text))
        {
            MessageBox.Show("Наименование не может быть пустым");
            return;
        }
        
        Subscription.PhotoPath = CopyImageToDocs(ImagePath);

        if (Subscription.Id == 0)
        {
            _context.Subscriptions.Add(Subscription);
            _context.SaveChanges();    
        }
        else
        {
            _context.Subscriptions.Update(Subscription);
            _context.SaveChanges();
        }
        
        MessageBox.Show("Сохранено!");
                
        if (NavigationService != null)
            NavigationService.GoBack();

    }

    private void CancelButton_OnClick(object sender, RoutedEventArgs e)
    {
        var result = MessageBox.Show("Отменить?", "", MessageBoxButton.YesNo);
        
        if (result == MessageBoxResult.Yes)
        {
            if (NavigationService != null) 
                NavigationService.GoBack();
        }
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    protected bool SetField<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value)) return false;
        field = value;
        OnPropertyChanged(propertyName);
        return true;
    }
}