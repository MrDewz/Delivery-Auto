﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Gym.Database;
using Gym.Models;

namespace Gym.Pages.ContentPages.Subscriptions;

public partial class SubscriptionPage : Page
{
    private DeliveryContext _context;
    
    public SubscriptionPage()
    {
        _context = new DeliveryContext();
        InitializeComponent();
        
        ShowTable("");
    }
    
    private void ShowTable(string search)
    {
        List<Subscription> subscriptions;

        if (string.IsNullOrWhiteSpace(search))
        {
            subscriptions = _context.Subscriptions.ToList();
        }
        else
        {
            subscriptions = _context.Subscriptions.Where(c => c.Name.Contains(search)).ToList();
        }
        
        if (subscriptions.Count == 0)
            NothingVisibleTextBlock.Visibility = Visibility.Visible;
        else
            NothingVisibleTextBlock.Visibility = Visibility.Collapsed;
        
        TableListView.ItemsSource = null;
        TableListView.ItemsSource = subscriptions;
    }
    
    private void SearchTextBox_OnTextChanged(object sender, TextChangedEventArgs e)
    {
        ShowTable(SearchTextBox.Text);
    }

    private void AddButton_OnClick(object sender, RoutedEventArgs e)
    {
        if (NavigationService != null) 
            NavigationService.Navigate(new AddEditSubscriptionPage());
    }

    private void EditButton_OnClick(object sender, RoutedEventArgs e)
    {
        var selected = TableListView.SelectedItem as Database.Subscription;
        
        if (selected != null)
        {
            if (NavigationService != null) 
                NavigationService.Navigate(new AddEditSubscriptionPage(selected));
        }
        else
        {
            MessageBox.Show("Необходимо выбрать абонимент");
        }
    }

    private void DeleteButton_OnClick(object sender, RoutedEventArgs e)
    {
        var selected = TableListView.SelectedItem as Database.Subscription;
        
        if (selected != null)
        {
            var result = MessageBox.Show("Удалить?", "", MessageBoxButton.YesNo);
            try
            {
                if (result == MessageBoxResult.Yes)
                {
                    _context.Subscriptions.Remove(selected);
                    _context.SaveChanges();

                    ShowTable(SearchTextBox.Text);
                }
            }
            catch
            {
                MessageBox.Show("Не удаётся удалить данные абонимента");
            }

            
            
        }
        else
        {
            MessageBox.Show("Необходимо выбрать абонимент");
        }
    }

    private void SubscriptionPage_OnLoaded(object sender, RoutedEventArgs e)
    {
        ShowTable(SearchTextBox.Text);
    }

    private void GenerateButton_OnClick(object sender, RoutedEventArgs e)
    {
        var selected = TableListView.SelectedItem as Database.Subscription;
        
        if (selected != null)
        {
            GenerateDocx.Generate(selected);
        }
        else
        {
            MessageBox.Show("Необходимо выбрать абонимент");
        }
    }
}