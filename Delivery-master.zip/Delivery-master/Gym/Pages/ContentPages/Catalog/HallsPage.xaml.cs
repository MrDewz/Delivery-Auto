﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Delivery.Database;
using Gym.Database;
using Microsoft.EntityFrameworkCore;


namespace Gym.Pages.ContentPages.Hall;

public partial class HallsPage : Page
{
    private DeliveryContext _context;
    List<Database.Product> product = new List<Database.Product>();
   // CartList cartList = new CartList();


    public HallsPage()
    {
        _context = new DeliveryContext();
        InitializeComponent();
        ShowTable("");
    }
    
    private void ShowTable(string search)
    {

        if (string.IsNullOrWhiteSpace(search))
        {
            product = _context.Products
                .Include(c => c.Type)
                .Include(c => c.Price)
                .ToList();
            
        }
        else
        {
            product = _context.Products.Where(c => c.Name.Contains(search)).ToList();
        }
        
        if (product.Count == 0)
            NothingVisibleTextBlock.Visibility = Visibility.Visible;
        else
            NothingVisibleTextBlock.Visibility = Visibility.Collapsed;
        
        TableListView.ItemsSource = null;
        TableListView.ItemsSource = product;
        
    }
    
    private void SearchTextBox_OnTextChanged(object sender, TextChangedEventArgs e)
    {
        ShowTable(SearchTextBox.Text);
    }

    private void AddButton_OnClick(object sender, RoutedEventArgs e)
    {
        var selected = TableListView.SelectedItem as Database.Product;

        if (selected != null)
        {
            try
            {
                //_context.Products.Remove(selected);
                //_context.SaveChanges();
                CartList.products.Add(selected);
                //ShowTable(SearchTextBox.Text);
                MessageBox.Show("Добавлено");
            }
            catch
            {
                MessageBox.Show("Невозможно добавить!");
            }
        }
        else
        {
            MessageBox.Show("Необходимо выбрать продукт");
        }
    }

    //private void EditButton_OnClick(object sender, RoutedEventArgs e)
    //{
    //    var selected = TableListView.SelectedItem as Database.Product;

    //    if (selected != null)
    //    {
    //        //if (NavigationService != null) 
    //    }
    //    else
    //    {
    //        MessageBox.Show("Необходимо выбрать занятие");
    //    }
    //}

    private void DeleteButton_OnClick(object sender, RoutedEventArgs e)
    {
        var selected = TableListView.SelectedItem as Database.Product;

        if (selected != null)
        {
            var result = MessageBox.Show("Удалить?", "", MessageBoxButton.YesNo);

            try
            {
                if (result == MessageBoxResult.Yes)
                {
                    _context.Products.Remove(selected);
                    _context.SaveChanges();

                    ShowTable(SearchTextBox.Text);
                }
            }
            catch
            {
                MessageBox.Show("Не возможно удалить зал!!!");
            }
        }
        else
        {
            MessageBox.Show("Необходимо выбрать занятие");
        }
    }

    private void HallsPage_OnLoaded(object sender, RoutedEventArgs e)
    {
        ShowTable(SearchTextBox.Text);
    }

}