﻿using Gym.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Delivery.Database;
using System.Runtime.CompilerServices;
using Microsoft.Win32;

namespace Delivery.Pages.ContentPages.AdminPanel.Workers
{
    /// <summary>
    /// Логика взаимодействия для WorkersAddEditPage.xaml
    /// </summary>
    /// 

    public partial class WorkersAddEditPage : Page, INotifyPropertyChanged
    {

        private readonly DeliveryContext _context;
        private string? _photo;

        public event PropertyChangedEventHandler? PropertyChanged;

        public string? Photo
        {
            get => _photo;
            set
            {
                if (value == _photo) return;
                _photo = value;
                OnPropertyChanged();
            }
        }

        public Product Product { get; set; }

        public Price Price { get; set; }

        public List<Gym.Database.Type> Type { get; set; } 

        //public List<Database.SportGroup> SportGroups { get; set; }

        public WorkersAddEditPage()
        {
            _context = new DeliveryContext();
            Product = new Product();
            Price = new Price();
            Type = new List<Gym.Database.Type>();
            //{ new Gym.Database.Type() { TypeId = -1, Name = "Не выбрано" } };

            InitializeComponent();

            DataContext = this;

            


            TypeComboBox.ItemsSource = Type;
        }

        public WorkersAddEditPage(Product product)
        {
            _context = new DeliveryContext();
            Product = product;
            Price = product.Price;
            Type = new List<Gym.Database.Type>()
            { new Gym.Database.Type() { TypeId = -1, Name = "Не выбрано" } };

            InitializeComponent();

            DataContext = this;




            TypeComboBox.ItemsSource = Type;
            TypeComboBox.SelectedItem = Type.FirstOrDefault(c => product.Type != null &&
                                                                     c.TypeId == product.Type.TypeId) ??
                                     Type.ElementAt(0);
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {

            if (String.IsNullOrWhiteSpace(NameTextBox.Text) || TypeComboBox.SelectedIndex == -1 || String.IsNullOrWhiteSpace(PriceTextBox.Text))
            {
                MessageBox.Show("Не все данные верны");
                return;
            }
            if (Product.ProductId == 0)
            {
                try
                {
                    Product product = new Product();
                    Price productPrice = new Price();
                    product.Name = NameTextBox.Text;
                    productPrice.Value = Convert.ToDecimal(PriceTextBox.Text);
                    productPrice.DateOfChange = DateTime.Now;
                    product.Description = DescriptionTextBox.Text;
                    product.Photo = _photo;
                    _context.Products.Add(product);
                    _context.Prices.Add(productPrice);
                    _context.SaveChanges();

                    MessageBox.Show("Сохранено!");

                    if (NavigationService != null)
                        NavigationService.GoBack();
                }
                catch (Exception)
                {
                    MessageBox.Show("Неверные данные");
                }
            }

        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Отменить?", "", MessageBoxButton.YesNo);

            if (result == MessageBoxResult.Yes)
            {
                if (NavigationService != null)
                    NavigationService.GoBack();
            }
        }

        private void DeleteImageButton_Click(object sender, RoutedEventArgs e)
        {
            SetImage(null);
        }

        private void ChooseImageButton_Click(object sender, RoutedEventArgs e)
        {
            var dir = "C:\\";
            var filter = "Image files (*.png)|*.png|All files (*.*)|*.*";

            // открываем диалог выбора файла
            var openFileDialog = new OpenFileDialog();

            openFileDialog.InitialDirectory = dir;
            openFileDialog.Filter = filter;

            // если показан
            if (openFileDialog.ShowDialog() == true)
                // если есть выбранный файл
                if (openFileDialog.FileName != string.Empty)
                    SetImage(openFileDialog.FileName);
        }
        private void SetImage(string? path)
        {
            Photo = path;
        }

        private void Image_OnDrop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                var data = e.Data.GetData(DataFormats.FileDrop);

                if (data != null)
                {
                    var files = (string[])data;

                    if (files.Length > 0)
                    {
                        var file = files[0];

                        if (file.EndsWith(".png") || file.EndsWith(".jpg"))
                            SetImage(file);
                    }
                }
            }
        }

        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
