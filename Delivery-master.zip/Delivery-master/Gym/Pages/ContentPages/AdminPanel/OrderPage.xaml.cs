﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Delivery.Database;
using Gym.Database;
using Microsoft.EntityFrameworkCore;

namespace Delivery.Pages.ContentPages.AdminPanel
{
    /// <summary>
    /// Логика взаимодействия для OrderPage.xaml
    /// </summary>
    public partial class OrderPage : Page
    {
        private DeliveryContext _context;
        List<Gym.Database.Delivery> deliveries = new List<Gym.Database.Delivery>();
        List<Order> orders = new List<Order>();

        public OrderPage()
        {
            _context = new DeliveryContext();
            InitializeComponent();
            ShowTable("");
        }

        private void ShowTable(string search)
        {
            orders.AddRange(_context.Orders.ToList());
            if (string.IsNullOrWhiteSpace(search))
            {
                deliveries = _context.Deliveries
                    .Include(c => c.Status)
                    .Include(c => c.Deliver)
                    .ToList();
            }

            if (deliveries.Count == 0)
                NothingVisibleTextBlock.Visibility = Visibility.Visible;
            else
                NothingVisibleTextBlock.Visibility = Visibility.Collapsed;

            TableListView.ItemsSource = null;
            TableListView.ItemsSource = deliveries;
        }


        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            ShowTable("");
        }

        private void DeleteOrderButton_Click(object sender, RoutedEventArgs e)
        {
            var selected = TableListView.SelectedItem as Gym.Database.Delivery;

            if (selected != null)
            {
                var result = MessageBox.Show("Удалить?", "", MessageBoxButton.YesNo);

                try
                {
                    if (result == MessageBoxResult.Yes)
                    {
                        _context.Remove(selected);
                        _context.SaveChanges();

                        ShowTable("");
                    }
                }
                catch
                {
                    MessageBox.Show("Невозможно удалить!");
                }
            }
            else
            {
                MessageBox.Show("Необходимо выбрать занятие");
            }
        }

        private void OpenOrderButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new OrderInfoPage());
        }
    }
}
