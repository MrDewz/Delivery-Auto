﻿using Delivery.Pages.ContentPages.AdminPanel.Workers;
using Gym.Database;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Delivery.Pages.ContentPages.AdminPanel
{
    /// <summary>
    /// Логика взаимодействия для AdminPanel.xaml
    /// </summary>
    public partial class AdminPanel : Page
    {
        private DeliveryContext _context;
        List<Product> product = new List<Product>();
        public AdminPanel()
        {
            _context = new DeliveryContext();
            InitializeComponent();
            ShowTable("");
        }

        private void ShowTable(string search)
        {

            if (string.IsNullOrWhiteSpace(search))
            {
                product = _context.Products
                    .Include(c => c.Type)
                    .Include(c => c.Price)
                    .ToList();
            }
            else
            {
                product = _context.Products.Where(c => c.Name.Contains(search)).ToList();
            }

            if (product.Count == 0)
                NothingVisibleTextBlock.Visibility = Visibility.Visible;
            else
                NothingVisibleTextBlock.Visibility = Visibility.Collapsed;

            TableListView.ItemsSource = null;
            TableListView.ItemsSource = product;
        }


        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddEditCatalogPage());
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            var selected = TableListView.SelectedItem as Product;

            if (selected != null)
            {
                if (NavigationService != null)
                    NavigationService.Navigate(new AddEditCatalogPage(selected));
            }
            else
            {
                MessageBox.Show("Необходимо выбрать клиента");
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var selected = TableListView.SelectedItem as Product;

            if (selected != null)
            {
                var result = MessageBox.Show("Удалить?", "", MessageBoxButton.YesNo);

                try
                {
                    if (result == MessageBoxResult.Yes)
                    {
                        _context.Products.Remove(selected);
                        _context.SaveChanges();

                        ShowTable(SearchTextBox.Text);
                    }
                }
                catch
                {
                    MessageBox.Show("Невозможно удалить!");
                }
            }
            else
            {
                MessageBox.Show("Необходимо выбрать занятие");
            }
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ShowTable(SearchTextBox.Text);
        }

        private void WorkersButton_Click(object sender, RoutedEventArgs e)
        {
           
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            ShowTable(SearchTextBox.Text);
        }

        private void Orders_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new OrderPage());
        }

        private void GenerateDocButton_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
