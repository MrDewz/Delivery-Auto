﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Gym.Database;

namespace Gym.Pages.ContentPages.Hall;

public partial class HallsPage : Page
{
    private DeliveryContext _context;
    
    public HallsPage()
    {
        _context = new DeliveryContext();
        InitializeComponent();
        
        ShowTable("");
    }
    
    private void ShowTable(string search)
    {
        List<Database.Hall> halls = new List<Database.Hall>();

        if (string.IsNullOrWhiteSpace(search))
        {
            halls = _context.Halls.ToList();
        }
        else
        {
            halls = _context.Halls.Where(c => c.Name.Contains(search)).ToList();
        }
        
        if (halls.Count == 0)
            NothingVisibleTextBlock.Visibility = Visibility.Visible;
        else
            NothingVisibleTextBlock.Visibility = Visibility.Collapsed;
        
        TableListView.ItemsSource = null;
        TableListView.ItemsSource = halls;
    }
    
    private void SearchTextBox_OnTextChanged(object sender, TextChangedEventArgs e)
    {
        ShowTable(SearchTextBox.Text);
    }

    private void AddButton_OnClick(object sender, RoutedEventArgs e)
    {
        if (NavigationService != null) 
            NavigationService.Navigate(new AddEditHallPage());
    }

    private void EditButton_OnClick(object sender, RoutedEventArgs e)
    {
        var selected = TableListView.SelectedItem as Database.Hall;
        
        if (selected != null)
        {
            if (NavigationService != null) 
                NavigationService.Navigate(new AddEditHallPage(selected));
        }
        else
        {
            MessageBox.Show("Необходимо выбрать занятие");
        }
    }

    private void DeleteButton_OnClick(object sender, RoutedEventArgs e)
    {
        var selected = TableListView.SelectedItem as Database.Hall;
        
        if (selected != null)
        {
            var result = MessageBox.Show("Удалить?", "", MessageBoxButton.YesNo);

            try
            {
                if (result == MessageBoxResult.Yes)
                {
                    _context.Halls.Remove(selected);
                    _context.SaveChanges();

                    ShowTable(SearchTextBox.Text);
                }
            }
            catch
            {
                MessageBox.Show("Не возможно удалить зал!!!");
            }
        }
        else
        {
            MessageBox.Show("Необходимо выбрать занятие");
        }
    }

    private void HallsPage_OnLoaded(object sender, RoutedEventArgs e)
    {
        ShowTable(SearchTextBox.Text);
    }
}