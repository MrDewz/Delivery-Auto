﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using Gym.Database;
using Microsoft.Win32;

namespace Gym.Pages.ContentPages.Hall;

public partial class AddEditHallPage : Page, INotifyPropertyChanged
{
    private string? _imagePath;
    public string? ImagePath
    {
        get => _imagePath;
        set
        {
            if (value == _imagePath) return;
            _imagePath = value;
            OnPropertyChanged();
        }
    }
    private Database.Hall hall;
    private DeliveryContext _context;
    
    public AddEditHallPage()
    {
        InitializeComponent();
        _context = new DeliveryContext();
        DataContext = this;
        hall = new Database.Hall();
    }

    public AddEditHallPage(Database.Hall hall)
    {
        InitializeComponent();
        _context = new DeliveryContext();

        this.hall = _context.Halls.FirstOrDefault(c => c.Id == hall.Id);
        
        if(hall.PhotoPath != null)
            SetImage(App.DocsPath + hall.PhotoPath);

        NameTextBox.Text = hall.Name;
        DataContext = this;
    }
    
    private void SaveButton_OnClick(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(NameTextBox.Text))
        {
            MessageBox.Show("Неверное имя");
            return;
        }
        
        if (_imagePath == "/Images/not-found-icon.jpg")
            _imagePath = null;

        if (hall.Id == 0)
        {
            hall = new Database.Hall(){Name = NameTextBox.Text, PhotoPath = CopyImageToDocs(_imagePath)};
            _context.Halls.Add(hall);
            _context.SaveChanges();
        }
        else
        {
            hall.Name = NameTextBox.Text;
            hall.PhotoPath = CopyImageToDocs(_imagePath);
            _context.Halls.Update(hall);
            _context.SaveChanges();
        }

        MessageBox.Show("Сохранено!");
        
        if (NavigationService != null) 
            NavigationService.GoBack();
    }

    private void CancelButton_OnClick(object sender, RoutedEventArgs e)
    {
        var result = MessageBox.Show("Отменить?", "", MessageBoxButton.YesNo);
        
        if (result == MessageBoxResult.Yes)
        {
            if (NavigationService != null) 
                NavigationService.GoBack();
        }
    }

    private void DeleteImageButton_OnClick(object sender, RoutedEventArgs e)
    {
        SetImage("/Images/not-found-icon.jpg");
    }
    
    private string? CopyImageToDocs(string? filePath)
    {
        if (filePath == null)
            return null;
        
        var path = $"C:\\Users\\{Environment.UserName}\\Documents\\Images\\";
        
        string fileName = "Image_" + App.GetTimeStamp() + ".png";
        File.Copy(filePath, path + fileName);
        return fileName;
    }

    private void ChooseImageButton_OnClick(object sender, RoutedEventArgs e)
    {
        var dir = "C:\\";
        var filter = "Image files (*.png)|*.png|All files (*.*)|*.*";

        // открываем диалог выбора файла
        var openFileDialog = new OpenFileDialog();

        openFileDialog.InitialDirectory = dir;
        openFileDialog.Filter = filter;

        // если показан
        if (openFileDialog.ShowDialog() == true)
            // если есть выбранный файл
            if (openFileDialog.FileName != string.Empty)
                SetImage(openFileDialog.FileName);
    }

    private void SetImage(string? path)
    {
        ImagePath = path;
    }
    
    private void Image_OnDrop(object sender, DragEventArgs e)
    {
        if (e.Data.GetDataPresent(DataFormats.FileDrop))
        {
            var data = e.Data.GetData(DataFormats.FileDrop);

            if (data != null)
            {
                var files = (string[]) data;

                if (files.Length > 0)
                {
                    var file = files[0];

                    if (file.EndsWith(".png") || file.EndsWith(".jpg"))
                        SetImage(file);
                }
            }
        }
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    protected bool SetField<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value)) return false;
        field = value;
        OnPropertyChanged(propertyName);
        return true;
    }
}