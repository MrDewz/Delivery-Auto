﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using Gym.Database;
using Gym.Models;
using Microsoft.EntityFrameworkCore;

namespace Gym.Pages.ContentPages.SportTable;

public partial class AddEditSportTablePage : Page
{
    private Database.SportTable _sportTable;
    private DeliveryContext _context;

    private List<Trainer> _trainers = new List<Trainer>();
    private List<Database.Hall> _halls = new List<Database.Hall>();
    private List<SportType> _sportTypes = new List<SportType>();
    private List<Database.SportGroup> _sportGroups = new List<Database.SportGroup>();

    public AddEditSportTablePage()
    {
        _context = new DeliveryContext();
        _sportTable = new Database.SportTable();
        InitializeComponent();
        
        LoadData();
        
        SetDefaultValues();
    }
    
    public AddEditSportTablePage(Database.SportTable sportTable)
    {
        _context = new DeliveryContext();
        _sportTable = _context.SportTables.FirstOrDefault(c => c.Id == sportTable.Id);
        InitializeComponent();
        
        LoadData();
        
        SetValues();
    }

    private void LoadData()
    {
        GetLists();
        
        TrainerCombobox.ItemsSource = _trainers;

        HallCombobox.ItemsSource = _halls;

        SportGroupCombobox.ItemsSource = _sportGroups;

        SportTypeCombobox.ItemsSource = _sportTypes;
    }

    private void GetLists()
    {
        _trainers.Add(new Trainer()
        {
            Id = -1, PersonalInfo = new PersonalInfo()
                { Passport = new Passport() { LastName = "Не выбрано" } }
        });
        
        _halls.Add(new Database.Hall(){ Id = -1, Name = "Не выбрано"});
        
        _sportGroups.Add(new Database.SportGroup(){Id = -1, Name = "Не выбрано"});
        
        _sportTypes.Add(new SportType(){Id = -1, Name = "Не выбрано"});
        
        var trainersdb = _context.Trainers
            .Include(c => c.PersonalInfo)
            .ThenInclude(c => c!.Passport)
            .ToList();
        
        var hallsdb = _context.Halls.ToList();

        var sportGroupsdb = _context.SportGroups.ToList();
        
        var sporttypesdb = _context.SportTypes.ToList();
        
        _sportTypes.AddRange(sporttypesdb);
        _sportGroups.AddRange(sportGroupsdb);
        _halls.AddRange(hallsdb);
        _trainers.AddRange(trainersdb);
    }

    private void SetDefaultValues()
    {
        TrainerCombobox.SelectedIndex = 0;

        HallCombobox.SelectedIndex = 0;

        SportTypeCombobox.SelectedIndex = 0;

        SportGroupCombobox.SelectedIndex = 0;
    }
    
    private void SetValues()
    {
        DatePickerTextBox.SelectedDate = _sportTable.Datetime; 
        
        TrainerCombobox.SelectedItem = _trainers.FirstOrDefault(c => c.Id == _sportTable.TrainerId);

        HallCombobox.SelectedItem = _halls.FirstOrDefault(c => c.Id == _sportTable.HallId);

        SportTypeCombobox.SelectedItem = _sportTypes.FirstOrDefault(c => c.Id == _sportTable.SportTypeId);

        SportGroupCombobox.SelectedItem = _sportGroups.FirstOrDefault(c => c.Id == _sportTable.SportGroupId);
    }

    private void SaveButton_OnClick(object sender, RoutedEventArgs e)
    {
        GetData();
        
        if (_sportTable.Datetime.Date == new DateTime().Date)
        {
            MessageBox.Show("Неверная дата");
            return;
        }

        if (_sportTable.SportGroupId == -1 ||
            _sportTable.HallId == -1 ||
            _sportTable.SportTypeId == -1 ||
            _sportTable.TrainerId == -1)
        {
            MessageBox.Show("Необходимо выбрать значения");
            return;
        }

        if (_sportTable.Id == 0)
            _context.Add(_sportTable);
        else
        {
            _context.SportTables.Update(_sportTable);
        }

        try
        {
            _context.SaveChanges();

            MessageBox.Show("Сохранено");
        
            if (NavigationService != null)
                NavigationService.GoBack();
        }
        catch (Exception exception)
        {
            MessageBox.Show("Ошибка сохранения данных");
        }

    }

    private void GetData()
    {
        if (DatePickerTextBox.SelectedDate != null)
            _sportTable.Datetime = (DateTime)DatePickerTextBox.SelectedDate;

        var sportType = SportTypeCombobox.SelectedItem as SportType;

        _sportTable.SportTypeId = sportType.Id;
        
        var sportGroup = SportGroupCombobox.SelectedItem as Database.SportGroup;
        
        _sportTable.SportGroupId = sportGroup.Id;

        var trainer = TrainerCombobox.SelectedItem as Trainer;

        _sportTable.TrainerId = trainer.Id;

        var hall = HallCombobox.SelectedItem as Database.Hall;

        _sportTable.HallId = hall.Id;
    }
    
    private void CancelButton_OnClick(object sender, RoutedEventArgs e)
    {
        var result = MessageBox.Show("Отменить?", "", MessageBoxButton.YesNo);
        
        if (result == MessageBoxResult.Yes)
        {
            if (NavigationService != null) 
                NavigationService.GoBack();
        }
    }
}