﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Gym.Database;
using Gym.Models;
using Microsoft.EntityFrameworkCore;

namespace Gym.Pages.ContentPages.SportTable;

public partial class SportTablePage : Page
{
    private readonly DeliveryContext _context;
    private DatePick SelectedMonth { get; set;}
    private List<DatePick> Dates { get; set; }
    
    public SportTablePage()
    {
        SelectedMonth = new DatePick() {Id = -1, Date = "Выберите дату"};
        
        Dates = new List<DatePick>() {SelectedMonth};
        Dates.AddRange(DatePicks.Months);
        
        _context = new DeliveryContext();
        
        InitializeComponent();

        MonthComboBox.ItemsSource = Dates;
        MonthComboBox.SelectedIndex = 0;
        
    }

    private void MonthComboBox_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        var selectedDate = MonthComboBox.SelectedItem as DatePick;

        ShowTable(selectedDate);
    }

    private void ShowTable(DatePick selectedDate)
    {
        List<Database.SportTable> sports;
        
        if (selectedDate.Id != -1)
        {
            sports = _context.SportTables
                .Include(c => c.Hall)
                .Include(c => c.Trainer)
                .ThenInclude(c => c.PersonalInfo)
                .ThenInclude(c => c.Passport)
                .Include(c => c.SportGroup)
                .Include(c => c.SportType)
                .Where(c => c.Datetime.Month == selectedDate.DateTime.Month)
                .ToList();
        }
        else
        {
            sports = _context.SportTables
                .Include(c => c.Hall)
                .Include(c => c.Trainer)
                .ThenInclude(c => c.PersonalInfo)
                .ThenInclude(c => c.Passport)
                .Include(c => c.SportType)
                .Include(c => c.SportGroup)
                .ToList();
        }


        if (sports.Count == 0)
            NothingVisibleTextBlock.Visibility = Visibility.Visible;
        else
            NothingVisibleTextBlock.Visibility = Visibility.Collapsed;
        
        TableListView.ItemsSource = null;
        TableListView.ItemsSource = sports;
    }
    
    private void AddButton_OnClick(object sender, RoutedEventArgs e)
    {
        if (NavigationService != null) 
            NavigationService.Navigate(new AddEditSportTablePage());
    }

    private void EditButton_OnClick(object sender, RoutedEventArgs e)
    {
        var selected = TableListView.SelectedItem as Database.SportTable;
        
        if (selected != null)
        {
            if (NavigationService != null) 
                NavigationService.Navigate(new AddEditSportTablePage(selected));
        }
        else
        {
            MessageBox.Show("Необходимо выбрать занятие");
        }
    }

    private void DeleteButton_OnClick(object sender, RoutedEventArgs e)
    {
        var selected = TableListView.SelectedItem as Database.SportTable;
        if (selected != null)
        {
            var result = MessageBox.Show("Удалить?", "", MessageBoxButton.YesNo);
            if (result == MessageBoxResult.Yes)
            {
                _context.Remove(selected);
                _context.SaveChanges();
                
                var selectedDate = MonthComboBox.SelectedItem as DatePick;
                
                ShowTable(selectedDate);
            }
        }
        else
        {
            MessageBox.Show("Необходимо выбрать занятие");
        }
    }

    private void SportTablePage_OnLoaded(object sender, RoutedEventArgs e)
    {
        var selectedDate = MonthComboBox.SelectedItem as DatePick;

        ShowTable(selectedDate);
    }
}