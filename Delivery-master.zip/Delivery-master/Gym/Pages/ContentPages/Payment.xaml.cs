﻿using Delivery.Database;
using Gym.Database;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Delivery.Pages.ContentPages
{
    /// <summary>
    /// Логика взаимодействия для Payment.xaml
    /// </summary>
    public partial class Payment : Page
    {
        private DeliveryContext _context;

        List<Order> orders = new List<Order>();

        //public List<Client> Client { get; set; }

        double Sum = 0;

        public Payment(double _Sum)
        {
            _context = new DeliveryContext();
            InitializeComponent();
            Sum = _Sum;
            //Client = new List<Client>();
            //Client.AddRange(_context.Clients.ToList());
        }

        private void CreateOrderButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Order order = new Order();
                order.DeliveryAddress = DeliveryAddress.Text;
                order.PaymentId = PayMethodComboBox.SelectedIndex + 1;
                order.ClientId = CurrentUser.users[0].Clients.FirstOrDefault(c => c.UserId == c.User.UserId).ClientId;
                //order.Client = Client;

                _context.Orders.Add(order);
                _context.SaveChanges();

                orders = _context.Orders
                    .Include(c => c.Client)
                    .Include(c => c.PaymentMethod).ToList();



                foreach (var item in CartList.products)
                {
                    Cart cart = new Cart();
                    cart.OrderId = orders[orders.Count - 1].OrderId;
                    cart.ProductId = item.ProductId;

                    _context.Carts.Add(cart);
                    _context.SaveChanges();
                }

                CartList.products.Clear();
                MessageBox.Show("Заказ успешно оформлен!");
            }
            catch (Exception)
            {

                MessageBox.Show("Что-то пошло не так");
            }
            if (string.IsNullOrWhiteSpace(DeliveryAddress.Text) || PayMethodComboBox.SelectedIndex == -1)
            {
                MessageBox.Show("Заполните данные!");
                return;
            }

        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            SumTB.Text = Sum.ToString();
        }
    }
}
