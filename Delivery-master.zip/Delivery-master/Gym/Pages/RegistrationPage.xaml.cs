﻿using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows;
using Gym.Database;
using ModernWpf.Controls;
using Page = System.Windows.Controls.Page;

namespace Gym.Pages;

public partial class RegistrationPage : Page
{
    private readonly DeliveryContext _context;
    private readonly Frame _frame;
    
    public RegistrationPage(Frame frame)
    {
        _frame = frame;
        _context = new DeliveryContext();
        InitializeComponent();
    }

    private void RegistrationButton_OnClick(object sender, RoutedEventArgs e)
    {
        var user = new User();
        var client = new Client();

        
        user.Login = LoginTextBox.Text;
        user.Password = PasswordBox.Password;
        user.RoleId = 3;
        user.Role = _context.Roles.Find(user.RoleId);
        client.User = user;
        client.Email = EmailTextBox.Text;
        client.FullName = FIOTextBox.Text;
        client.TelephoneNumber = PhoneNumberTextBox.Text;

        if (Validate(user))
        {
            try
            {
                _context.Add(user);
                _context.Add(client);
                _context.SaveChanges();

                MessageBox.Show("Успешная регистрация");

                if (NavigationService != null)
                    NavigationService.Navigate(new MainPage(user, _frame));
            }
            catch (System.Exception)
            {

                MessageBox.Show("Регистрация не удалась! Попробуйте другой логин");
            }

        }
        else
        {
            MessageBox.Show("Не все данные верны");
        }

    }

    private bool Validate(User user)
    {
        if (string.IsNullOrWhiteSpace(user.Login))
            return false;

        if (string.IsNullOrWhiteSpace(user.Password))
            return false;
        return true;
    }

    private bool ValidateEmail(string email)
    {
        return new EmailAddressAttribute().IsValid(email);
    }
    
    private void CancelButton_OnClick(object sender, RoutedEventArgs e)
    {
        if (NavigationService != null) 
            NavigationService.GoBack();
    }
}