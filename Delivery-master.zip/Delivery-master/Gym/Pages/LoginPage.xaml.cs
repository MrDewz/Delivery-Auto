﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Delivery.Database;
using Gym.Database;
using Microsoft.EntityFrameworkCore;
using Frame = ModernWpf.Controls.Frame;

namespace Gym.Pages;

public partial class LoginPage : Page
{
    private readonly DeliveryContext _context;
    private readonly Frame _frame;
    
    public LoginPage(Frame frame)
    {
        _frame = frame;
        _context = new DeliveryContext();
        InitializeComponent();
    }

    private void LoginButton_OnClick(object sender, RoutedEventArgs e)
    {
        string login = LoginTextBox.Text;
       
        string password = PasswordBox.Password;

        if (login.Length > 250 || password.Length > 250)
        {
            MessageBox.Show("Неверный логин или пароль");
            return;
        }
        
        // поиск по логину или почте
        var user = _context.Users.FirstOrDefault(c => c.Login == login);

        if (user == null)
            MessageBox.Show("Пользователь не найден!");
        else
        {
            if (password == user.Password)
            {
                user = _context.Users
                    .Include(c => c.Role)
                    .Include(c => c.Clients)
                    //.Include(c => c.Clients)
                    //.ThenInclude(c => c.Users)
                    .FirstOrDefault(c => c.UserId == user.UserId);
                CurrentUser.users.Add(user);
                if (NavigationService != null) 
                    NavigationService.Navigate(new MainPage(user, _frame));
                
                MessageBox.Show("Вход выполнен");
            }
            else
            {
                MessageBox.Show("Неверный пароль");
            }
        }
    }

    private void RegisterButton_OnClick(object sender, RoutedEventArgs e)
    {
        if (NavigationService != null) 
            NavigationService.Navigate(new RegistrationPage(_frame));
    }
}