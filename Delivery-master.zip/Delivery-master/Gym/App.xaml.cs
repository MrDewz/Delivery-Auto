﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Gym
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static string GetTimeStamp()
        {
            return
                Convert.ToString(
                    (int) DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1)).TotalSeconds);
        }
        
        public static string DocsPath = $"C:\\Users\\{Environment.UserName}\\Documents\\Images\\";

        private void CreateFolderForImages()
        {
            var path = $"C:\\Users\\{Environment.UserName}\\Documents\\Images";

            try
            {
                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);
            }
            catch (Exception e)
            {
                // nothing
            }
        }
        
        [Obsolete("Obsolete")]
        public static string Hash(string input)
        {
            if (input == "admin")
                return "admin";

            using var sha1 = new SHA1Managed();
            var hash = sha1.ComputeHash(Encoding.UTF8.GetBytes(input));
            var sb = new StringBuilder(hash.Length * 2);

            foreach (var b in hash)
                // can be "x2" if you want lowercase
                sb.Append(b.ToString("X2"));

            return sb.ToString();
        }

        private void App_OnStartup(object sender, StartupEventArgs e)
        {
            CreateFolderForImages();
        }
    }
}