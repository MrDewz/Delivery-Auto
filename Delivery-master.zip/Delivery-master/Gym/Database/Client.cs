﻿using System;
using System.Collections.Generic;

namespace Gym.Database;

public partial class Client
{
    public int ClientId { get; set; }

    public string FullName { get; set; }

    public string Email { get; set; }

    public string TelephoneNumber { get; set; }

    public int UserId { get; set; }

    public User? User { get; set; }

    public virtual ICollection<Order> Orders { get; } = new List<Order>();

}
