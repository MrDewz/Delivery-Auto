﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gym.Database
{
    public partial class PaymentMethod
    {
        public int PaymentId { get; set; }

        public string Name { get; set; }

        public virtual ICollection<Order> Orders { get; } = new List<Order>();

    }
}
