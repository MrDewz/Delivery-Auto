﻿using Gym.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delivery.Database
{
    public partial class Status
    {
        public int StatusId { get; set; }

        public string Name { get; set; }

        public virtual ICollection<Gym.Database.Delivery> Deliveries { get; } = new List<Gym.Database.Delivery>();
    }
}
