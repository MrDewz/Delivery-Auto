﻿using Gym.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delivery.Database
{
    public class CurrentUser
    {
        public static List<User> users = new List<User>();
    }
}
