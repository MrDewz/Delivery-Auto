﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gym.Database
{
    public partial class Price
    {
        public int PriceId { get; set; }

        public decimal Value { get; set; }

        public DateTime DateOfChange { get; set; }

        public virtual ICollection<Product> Products { get; } = new List<Product>();

    }
}
