﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gym.Database
{
    public partial class Order
    {
        public int OrderId { get; set; }
        public string DeliveryAddress { get; set; }
        public int ClientId { get; set; }
        public int PaymentId { get; set; }
        public Client Client { get; set; }
        public PaymentMethod PaymentMethod { get; set; }

        public virtual ICollection<Cart> Carts { get; } = new List<Cart>();
    }
}
