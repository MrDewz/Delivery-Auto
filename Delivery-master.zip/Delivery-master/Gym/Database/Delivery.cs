﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Delivery.Database;

namespace Gym.Database
{
    public partial class Delivery
    {
        public int DeliveryId { get; set; }

        public int DeliverId { get; set; }

        public int ManagerId { get; set; }

        public int CartId { get; set; }

        public int StatusId { get; set; }

        public decimal Sum { get; set; }

        public virtual Deliver? Deliver { get; set; }

        public virtual Manager? Manager { get; set; }

        public virtual Cart? Cart { get; set; }

        public virtual Status? Status { get; set; }
    }
}
