﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gym.Database
{
    public partial class Deliver
    {
        public int DeliverId { get; set; }

        public string FullName { get; set; }

        public string TelephoneNumber{ get; set; }

        public string? Email { get; set; }

        public int? UserId { get; set; }

        public User? User { get; set; }

        public virtual ICollection<Delivery> Deliveries { get; } = new List<Delivery>();

    }
}
