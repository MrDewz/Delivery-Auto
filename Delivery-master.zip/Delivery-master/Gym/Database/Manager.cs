﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gym.Database
{
    public partial class Manager
    {
        public int ManagerId { get; set; }

        public string FullName { get; set; }

        public string Email { get; set; }

        public string TelephoneNumber { get; set; }

        public int UserId { get; set; }

        public User? User { get; set; }

        public virtual ICollection<Delivery> Deliveryies { get; } = new List<Delivery>();


    }
}
