﻿//using System.Linq;

//namespace Gym.Database;

//public partial class Client
//{
//    public SportGroup? SportGroup
//    {
//        get
//        {
//            if(ClientSportGroups.Count > 0)
//                return ClientSportGroups.ElementAt(0).SportGroup;

//            return null;
//        }
//    }
//}