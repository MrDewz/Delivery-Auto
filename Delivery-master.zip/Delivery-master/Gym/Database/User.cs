﻿using System;
using System.Collections.Generic;

namespace Gym.Database;

public partial class User
{
    public int UserId { get; set; }

    public string Login { get; set; } = null!;

    public string Password { get; set; } = null!;

    public int RoleId { get; set; }

    public virtual Role? Role { get; set; }

    public virtual ICollection<Client> Clients { get; } = new List<Client>();

    public virtual ICollection<Manager> Managers { get; } = new List<Manager>();

    public virtual ICollection<Deliver> Delivers { get; } = new List<Deliver>();
}
