﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gym.Database;

namespace Delivery.Database
{
    public class CartList
    {
        public static List<Product> products = new List<Product>();
    }
}
