﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gym.Database
{
    public partial class Product
    {
        public int ProductId { get; set; }

        public string Name { get; set; }

        public string? Description { get; set; }

        public string? Photo { get; set; }

        public int PriceId { get; set; }

        public int TypeId { get; set; }

        public virtual Price Price { get; set; }

        public virtual Type Type { get; set; }

        public virtual ICollection<Cart> Carts { get; } = new List<Cart>();

    }
}
