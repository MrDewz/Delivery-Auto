﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Delivery.Database;

namespace Gym.Database;

public partial class DeliveryContext : DbContext
{
    public DeliveryContext()
    {
    }

    public DeliveryContext(DbContextOptions<DeliveryContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Role> Roles { get; set; }
    public virtual DbSet<Client> Clients { get; set; }
    public virtual DbSet<PaymentMethod> PaymentMethods { get; set; }
    public virtual DbSet<Order> Orders { get; set; }

    public virtual DbSet<User> Users { get; set; }

    public virtual DbSet<Deliver> Delivers { get; set; }

    public virtual DbSet<Delivery> Deliveries { get; set; }

    public virtual DbSet<Manager> Managers { get; set; }

    public virtual DbSet<Cart> Carts { get; set; }

    public virtual DbSet<Product> Products { get; set; }

    public virtual DbSet<Price> Prices { get; set; }

    public virtual DbSet<Type> Types { get; set; }
    public virtual DbSet<Status> Statuses { get; set; }


    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=.\\SQLEXPRESS;Database=Kursovaya;Trusted_Connection=True;Integrated Security=True;TrustServerCertificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {

        modelBuilder.Entity<Product>(entity =>
        {
            entity.HasKey(e => e.ProductId).HasName("PK__Product__B40CC6CD526CF9CB");

            entity.ToTable("Product");

            entity.Property(e => e.ProductId).HasColumnName("ProductId");

            entity.Property(e => e.Name)
               .HasMaxLength(100)
               .IsUnicode(false)
               .HasColumnName("Name");
            entity.Property(e => e.Description)
               .HasMaxLength(300)
               .IsUnicode(false)
               .HasColumnName("Description");
            entity.Property(e => e.Photo)
               .HasMaxLength(300)
               .IsUnicode(false)
               .HasColumnName("Photo");

            entity.Property(e => e.PriceId).HasColumnName("PriceId");
            entity.Property(e => e.TypeId).HasColumnName("TypeId");

            entity.HasOne(d => d.Price).WithMany(p => p.Products)
                .HasForeignKey(d => d.PriceId)
                .HasConstraintName("FK__Product__PriceId__6B24EA82");
            entity.HasOne(d => d.Type).WithMany(p => p.Products)
                .HasForeignKey(d => d.TypeId)
                .HasConstraintName("FK__Product__TypeId__6C190EBB");
        });

        modelBuilder.Entity<Client>(entity =>
        {
            entity.HasKey(e => e.ClientId).HasName("PK__Client__E67E1A24D59039DE");

            entity.ToTable("Client");

            entity.Property(e => e.ClientId).HasColumnName("ClientId");

            entity.Property(e => e.FullName)
               .HasMaxLength(100)
               .IsUnicode(false)
               .HasColumnName("FullName"); 
            entity.Property(e => e.Email)
               .HasMaxLength(100)
               .IsUnicode(false)
               .HasColumnName("Email"); 
            entity.Property(e => e.TelephoneNumber)
               .HasMaxLength(11)
               .IsUnicode(false)
               .HasColumnName("TelephoneNumber");

            entity.Property(e => e.UserId).HasColumnName("UserId");

            entity.HasOne(d => d.User).WithMany(p => p.Clients)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK__Client__UserId__01142BA1");
        });

        modelBuilder.Entity<PaymentMethod>(entity =>
        {
            entity.HasKey(e => e.PaymentId).HasName("PK__PaymentM__9B556A38BA902F10");

            entity.ToTable("PaymentMethod");

            entity.Property(e => e.PaymentId).HasColumnName("PaymentId");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("Name");

        });

        modelBuilder.Entity<Manager>(entity =>
        {
            entity.HasKey(e => e.ManagerId).HasName("PK__Manager__3BA2AAE18797D57C");

            entity.ToTable("Manager");

            entity.Property(e => e.ManagerId).HasColumnName("ManagerId");
            entity.Property(e => e.FullName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("FullName");
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("Email");
            entity.Property(e => e.TelephoneNumber)
                .HasMaxLength(11)
                .IsUnicode(false)
                .HasColumnName("TelephoneNumber");

            entity.Property(e => e.UserId).HasColumnName("UserId");

            entity.HasOne(d => d.User).WithMany(p => p.Managers)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK__Manager__UserId__02FC7413");
        });

        modelBuilder.Entity<Order>(entity =>
        {
            entity.HasKey(e => e.OrderId).HasName("PK__Order__C3905BCF80D81AB8");

            entity.ToTable("Order");

            entity.Property(e => e.OrderId).HasColumnName("OrderId");
            entity.Property(e => e.DeliveryAddress)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("DeliveryAddress");
            entity.Property(e => e.ClientId).HasColumnName("ClientId");
            entity.Property(e => e.PaymentId).HasColumnName("PaymentId");

            entity.HasOne(d => d.Client).WithMany(p => p.Orders)
                .HasForeignKey(d => d.ClientId)
                .HasConstraintName("FK__Order__ClientId__656C112C");
            entity.HasOne(d => d.PaymentMethod).WithMany(p => p.Orders)
                .HasForeignKey(d => d.PaymentId)
                .HasConstraintName("FK__Order__PaymentId__693CA210");
        });

        modelBuilder.Entity<Deliver>(entity =>
        {
            entity.HasKey(e => e.DeliverId).HasName("PK__Deliver__39A9BE9C0B180125");

            entity.ToTable("Deliver");

            entity.Property(e => e.DeliverId).HasColumnName("DeliverId");
            entity.Property(e => e.FullName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("FullName");
            entity.Property(e => e.TelephoneNumber)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("TelephoneNumber");
            entity.Property(e => e.Email)
                .HasMaxLength(150)
                .IsUnicode(false)
                .HasColumnName("Email");
            entity.Property(e => e.UserId).HasColumnName("UserId");

            entity.HasOne(d => d.User).WithMany(p => p.Delivers)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK__Deliver__UserId__02084FDA");
        });

        modelBuilder.Entity<Price>(entity =>
        {
            entity.HasKey(e => e.PriceId).HasName("PK__Price__49575BAF6C067B13");

            entity.ToTable("Price");

            entity.Property(e => e.PriceId).HasColumnName("PriceId");
            entity.Property(e => e.Value)
                .HasColumnType("decimal(18, 2)")
                .IsUnicode(false)
                .HasColumnName("Price");
            entity.Property(e => e.DateOfChange)
                .HasColumnType("datetime")
                .HasColumnName("DateOfChange");
        });

        modelBuilder.Entity<Type>(entity =>
        {
            entity.HasKey(e => e.TypeId).HasName("PK__Type__516F03B562DB8B1D");

            entity.ToTable("Type");

            entity.Property(e => e.TypeId).HasColumnName("TypeId");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("Name");
        });

        modelBuilder.Entity<Cart>(entity =>
        {
            entity.HasKey(e => e.CartId).HasName("PK__Cart__51BCD7B744006288");

            entity.ToTable("Cart");

            entity.Property(e => e.CartId).HasColumnName("CartId");
            entity.Property(e => e.ProductId).HasColumnName("ProductId");
            entity.Property(e => e.OrderId).HasColumnName("OrderId");

            entity.HasOne(d => d.Order).WithMany(p => p.Carts)
                .HasForeignKey(d => d.OrderId)
                .HasConstraintName("FK__Cart__OrderId__68487DD7");
            entity.HasOne(d => d.Product).WithMany(p => p.Carts)
                .HasForeignKey(d => d.ProductId)
                .HasConstraintName("FK__Cart__ProductId__6A30C649");
        });

        modelBuilder.Entity<Delivery>(entity =>
        {
            entity.HasKey(e => e.DeliveryId).HasName("PK__Delivery__626D8FCEA39F6AEA");

            entity.ToTable("Delivery");

            entity.Property(e => e.DeliveryId).HasColumnName("DeliveryId");
            entity.Property(e => e.DeliverId).HasColumnName("DeliverId");
            entity.Property(e => e.ManagerId).HasColumnName("ManagerId");
            entity.Property(e => e.CartId).HasColumnName("CartId");
            entity.Property(e => e.Sum).HasColumnName("Sum");

            entity.HasOne(d => d.Cart).WithMany(p => p.Deliveries)
                .HasForeignKey(d => d.CartId)
                .HasConstraintName("FK__Delivery__CartId__6D0D32F4");
            entity.HasOne(d => d.Deliver).WithMany(p => p.Deliveries)
                .HasForeignKey(d => d.DeliverId)
                .HasConstraintName("FK__Delivery__Delive__6754599E");
            entity.HasOne(d => d.Manager).WithMany(p => p.Deliveryies)
                .HasForeignKey(d => d.ManagerId)
                .HasConstraintName("FK__Delivery__Manage__66603565");
            entity.HasOne(d => d.Status).WithMany(p => p.Deliveries)
                .HasForeignKey(d => d.StatusId)
                .HasConstraintName("FK__Delivery__Status__05D8E0BE");
        });

        modelBuilder.Entity<Role>(entity =>
        {
            entity.HasKey(e => e.RoleId).HasName("PK__Role__8AFACE1A0253D0F9");

            entity.ToTable("Role");

            entity.Property(e => e.RoleId).HasColumnName("RoleId");

            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("Name");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("PK__User__1788CC4C80B7E1F2");

            entity.ToTable("User");

            entity.Property(e => e.UserId).HasColumnName("UserId");
            entity.Property(e => e.Login)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("Login");
            entity.Property(e => e.Password)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("Password");
            entity.Property(e => e.RoleId).HasColumnName("RoleId");

            entity.HasOne(d => d.Role).WithMany(p => p.Users)
                .HasForeignKey(d => d.RoleId)
                .HasConstraintName("FK__User__RoleId__6477ECF3");
                //.IsUnique();
            entity.HasAlternateKey(u => u.Login);
        });

        modelBuilder.Entity<Status>(entity =>
        {
            entity.HasKey(e => e.StatusId).HasName("PK__Status__C8EE20634303C85D");

            entity.ToTable("Status");

            entity.Property(e => e.StatusId).HasColumnName("StatusId");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("Name");

        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
