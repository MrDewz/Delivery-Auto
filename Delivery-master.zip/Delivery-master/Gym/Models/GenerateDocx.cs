﻿//using System;
//using System.Diagnostics;
//using System.Windows;
//using Gym.Database;
//using ModernWpf.Controls;
//using Xceed.Words.NET;

//namespace Gym.Models;

//public class GenerateDocx
//{
//    public static void Generate(Subscription subscription)
//    {
//        var fileName = subscription.Name + ".docx";

//        var fullPath = App.DocsPath + fileName;

//        try
//        {
//            using var doc = DocX.Create(fullPath);

//            // добавляем фото рецепта(если есть)
//            try
//            {
//                var image = doc.AddImage(subscription.ImagePath);
//                var pic = image.CreatePicture(300f, 300f);

//                var p = doc.InsertParagraph("");
//                p.AppendPicture(pic);
//            }
//            catch (Exception e)
//            {
//                doc.InsertParagraph($"(Фото отсутствует)").FontSize(20);
//            }

//            doc.InsertParagraph($"Наименование: {subscription.Name}").FontSize(20);

//            doc.InsertParagraph($"Цена: {subscription.Price}").FontSize(20);
            
//            doc.Save();

//            ShowFileInExplorer(fullPath);
//        }
//        catch (Exception e)
//        {
//            MessageBox.Show("Ошибка генерации файла");
//        }
//    }
    
    
//    private static void ShowFileInExplorer(string path)
//    {
//        Process.Start(new ProcessStartInfo
//            {
//                FileName = "explorer", Arguments = $"/n, /select, {path}"
//            }
//        );
//    }
//}