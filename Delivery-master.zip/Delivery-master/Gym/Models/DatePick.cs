﻿using System;

namespace Gym.Models;

public class DatePick
{
    public int Id { get; set; }
    public string Date { get; set; }
    public DateTime DateTime { get; set; }
}