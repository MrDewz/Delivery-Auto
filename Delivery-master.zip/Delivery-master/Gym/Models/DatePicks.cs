﻿using System;
using System.Collections.Generic;
using System.Windows.Documents;

namespace Gym.Models;

public class DatePicks
{
    public static List<DatePick> Months = new List<DatePick>()
    {
        new DatePick() {Id = 1, Date = "Январь", DateTime = new DateTime(1971, 1, 1)},
        new DatePick() {Id = 2, Date = "Февраль", DateTime = new DateTime(1971, 2, 1)},
        new DatePick() { Id = 3, Date = "Март", DateTime = new DateTime(1971, 3, 1)},
        new DatePick() { Id = 4, Date = "Апрель", DateTime = new DateTime(1971, 4, 1)},
        new DatePick() { Id = 5, Date = "Май", DateTime = new DateTime(1971, 5, 1)},
        new DatePick() { Id = 6, Date = "Июнь", DateTime = new DateTime(1971, 6, 1)},
        new DatePick() { Id = 7, Date = "Июль", DateTime = new DateTime(1971, 7, 1)},
        new DatePick() { Id = 8, Date = "Август", DateTime = new DateTime(1971, 8, 1)},
        new DatePick() { Id = 9, Date = "Сентябрь", DateTime = new DateTime(1971, 9, 1)},
        new DatePick() { Id = 10, Date = "Октябрь", DateTime = new DateTime(1971, 10, 1)},
        new DatePick() { Id = 11, Date = "Ноябрь", DateTime = new DateTime(1971, 11, 1)},
        new DatePick() { Id = 12, Date = "Декабрь", DateTime = new DateTime(1971, 12, 1)}
    };
}